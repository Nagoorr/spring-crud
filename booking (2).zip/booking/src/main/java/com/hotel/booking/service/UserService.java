package com.hotel.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.booking.dao.Dao;
import com.hotel.booking.dto.User;

// class is used to provide service for controller and dao
@Service
public class UserService {

	@Autowired
	private Dao dao;
	
	public boolean register(User user) {
		
	   boolean status=dao.registerUser(user);
	    return status;
	}
	

	
	
}
