package com.hotel.booking.dao;


import com.hotel.booking.dto.User;

// interface to define the abstract methods regarding service for user,hotel
public interface Dao {
	
	boolean registerUser(User user);
}
