package com.hotel.booking.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import org.springframework.stereotype.Repository;
import com.hotel.booking.dto.User;
import com.hotel.booking.util.JpaUtil;

//implementation class of dao interface to provide implementation for abstract methods
@Repository
public class DaoImpl implements Dao{

	EntityManagerFactory entityManagerFactory=JpaUtil.getEntityManagerFactory();
	
	@Override
	public boolean registerUser(User user) {
			boolean status=false;

			EntityManager entityManager =entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			try
			{
				entityManager.persist(user);
				entityManager.getTransaction().commit();
				status= true;
			}catch (Exception e) {
				e.printStackTrace();
				entityManager.getTransaction().rollback();
			}

			entityManager.close();
			return status;
		}
	}


