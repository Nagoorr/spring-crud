package com.hotel.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hotel.booking.dto.User;
import com.hotel.booking.service.UserService;



// class regarding user register/login/update
@Controller
@RequestMapping("/user")
public class UserController {
	

	@Autowired
	private UserService userService;
	
	
	// method to return login.jsp page
	@RequestMapping(value="/loginpage",method=RequestMethod.GET)
	public String loginPage()
	{
		return "login";
	}
	
	//method to return a register.jsp file
	@RequestMapping(value="/registerpage",method=RequestMethod.GET)
	public String registerPage()
	{
		return "register";
	}

	//method to return a home page or welcome page
	@RequestMapping(value="/homepage",method=RequestMethod.GET)
	public String homePage()
	{
		return "homepage";
	}
	
	// method to register the user details and save to database
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView  registerUser(@ModelAttribute User user) {


		boolean result=userService.register(user);

		if(result)
		{
			System.out.println(user);
			return new ModelAndView("Login");

		}
		else
			return new ModelAndView("Register");

	}
	
	

}
