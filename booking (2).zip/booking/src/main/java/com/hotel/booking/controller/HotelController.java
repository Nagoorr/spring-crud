package com.hotel.booking.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class HotelController {
	
	// method to return addhotel.jsp file
	@RequestMapping(value="/addhotelpage",method=RequestMethod.GET)
	public String addHotel()
	{
		return "addhotel";
	}
	
	//method to return updatehotel.jsp file
	@RequestMapping(value="/updatehotelpage",method=RequestMethod.GET)
	public String updateHotel()
	{
		return "updatehotel";
	}

}
